package checkers;
import java.awt.*;

public class Piece {
    private Color color;
    Piece(Color _color)
    {
        color = _color;       
    }
    public Color getColor()
    {
        return (color);
    }
    static void MovePiecePixel(int xpixel, int ypixel){
        int NUM_ROWS = 8;
        int NUM_COLUMNS = 8;      
        Piece board[][] = new Piece[NUM_ROWS][NUM_COLUMNS];
        if (xpixel < 0 || xpixel > Window.getWidth2())
            return;
        if (ypixel < 0 || ypixel > Window.getHeight2())
            return;  
        int ydelta = Window.getHeight2()/NUM_ROWS;
        int xdelta = Window.getWidth2()/NUM_COLUMNS;
        int column = xpixel/xdelta;   
        int row = ypixel/ydelta;   
        if (board[row][column] != null){
            //Blue is the top pieces
            if (Player.GetCurrentPlayer().getColor() == Color.blue){
                
            }
            //Yellow is the bottom pieces
            if (Player.GetCurrentPlayer().getColor() == Color.yellow){
                
            }
        }
    }
    public void draw(Graphics2D g,int row,int column,int xdelta,int ydelta) {
        row = 0;
        column = 0;
        int mainXlocation = row + xdelta;
        int mainYlocation = column + ydelta;
            color = Color.yellow;
            g.setColor(color);
            g.fillOval(Window.getX(row + xdelta * 6), Window.getY(column +ydelta * 7), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta * 4), Window.getY(column +ydelta * 7), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta * 2), Window.getY(column +ydelta * 7), xdelta, ydelta);
            g.fillOval(Window.getX(row), Window.getY(column +ydelta * 7), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta), Window.getY(column +ydelta * 6), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta * 3), Window.getY(column +ydelta * 6), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta * 5), Window.getY(column +ydelta * 6), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta * 7), Window.getY(column +ydelta * 6), xdelta, ydelta);
            color = Color.blue;
            g.setColor(color);
            g.fillOval(Window.getX(row + xdelta * 6), Window.getY(column + ydelta), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta * 4), Window.getY(column + ydelta), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta * 2), Window.getY(column + ydelta), xdelta, ydelta);
            g.fillOval(Window.getX(row), Window.getY(column + ydelta), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta), Window.getY(column), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta * 3), Window.getY(column), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta * 5), Window.getY(column), xdelta, ydelta);
            g.fillOval(Window.getX(row + xdelta * 7), Window.getY(column), xdelta, ydelta);
    }
    
}
