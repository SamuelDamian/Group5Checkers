package checkers;

import java.io.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import javax.swing.*;

public class Checkers extends JFrame implements Runnable {
    boolean animateFirstTime = true;
    Image image;
    Graphics2D g;
    Image checkersBoardImage;
    int mouseClicks;

    public static void main(String[] args) {
        Checkers frame = new Checkers();
        frame.setSize(Window.WINDOW_WIDTH, Window.WINDOW_HEIGHT);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public Checkers() {
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {

                if (e.BUTTON1 == e.getButton() ) {
                    mouseClicks++;
                    if (mouseClicks == 2){
                        int x = e.getX() - Window.getX(0);
                        int y = e.getY() - Window.getY(0);
                        Board.BoardSetupPixel(x,y);
                        Piece.MovePiecePixel(x,y);
                    }
                    else{
                       
                    }
                }

                if (e.BUTTON3 == e.getButton()) {
                }

                repaint();
            }
        });
           

    addMouseMotionListener(new MouseMotionAdapter() {
      public void mouseDragged(MouseEvent e) {
          Board.Draw(g);
         

        repaint();
      }
    });

    addMouseMotionListener(new MouseMotionAdapter() {
      public void mouseMoved(MouseEvent e) {

        repaint();
      }
    });

        addKeyListener(new KeyAdapter() {

            public void keyPressed(KeyEvent e) {
                if (e.VK_UP == e.getKeyCode()) {
                } else if (e.VK_DOWN == e.getKeyCode()) {
                } else if (e.VK_LEFT == e.getKeyCode()) {
                } else if (e.VK_RIGHT == e.getKeyCode()) {
                } else if (e.VK_ESCAPE == e.getKeyCode()) {
                    reset();
                }
                repaint();
            }
        });
        init();
        start();
    }
    Thread relaxer;
////////////////////////////////////////////////////////////////////////////
    public void init() {
        requestFocus();
    }
////////////////////////////////////////////////////////////////////////////
    public void destroy() {
    }
////////////////////////////////////////////////////////////////////////////
    public void paint(Graphics gOld) {
        if (image == null || Window.xsize != getSize().width || Window.ysize != getSize().height) {
            Window.xsize = getSize().width;
            Window.ysize = getSize().height;
            image = createImage(Window.xsize, Window.ysize);
            g = (Graphics2D) image.getGraphics();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
        }
//fill background
       
        g.setColor(Color.black);
        g.fillRect(0, 0, Window.xsize, Window.ysize);

        int x[] = {Window.getX(0), Window.getX(Window.getWidth2()), Window.getX(Window.getWidth2()), Window.getX(0), Window.getX(0)};
        int y[] = {Window.getY(0), Window.getY(0), Window.getY(Window.getHeight2()), Window.getY(Window.getHeight2()), Window.getY(0)};
//fill border
        g.setColor(Color.white);
        g.fillPolygon(x, y, 4);
// draw border
        g.setColor(Color.black);
        g.drawPolyline(x, y, 5);
       
        g.drawImage(checkersBoardImage,Window.getX(0),Window.getY(0),
                Window.getWidth2(),Window.getHeight2(),this);

        if (animateFirstTime) {
            gOld.drawImage(image, 0, 0, null);
            return;
        }
       
        if (mouseClicks == 1){
            g.setColor(Color.black);
            g.fillRect(Window.getX(0), Window.getY(0), Window.getWidth2(), Window.getHeight2());
            g.setColor(Color.blue);
            g.fillRect(Window.getX(180), Window.getY(175), 250, 110);
            g.setColor(Color.red);
            g.drawRect(Window.getX(180), Window.getY(175), 250, 110);
            g.setColor(Color.yellow);
            g.setFont(new Font("Arial",Font.PLAIN,50));
            g.drawString("Checkers",Window.getX(200), Window.getY(250));
        }
        double heightNum = 0.25;
        if (mouseClicks == 0){
           
           
            g.setColor(Color.lightGray);
            g.fillRect(Window.getX(0), Window.getY(0), Window.getWidth2(), Window.getHeight2());//background
           
            Color newColo = new Color(128, 64, 64);
            g.setColor(newColo);
            g.fillRect(Window.getWidth2()/2-175, (int) (Window.getHeight2()*heightNum)-55,400,70);// text background
           
           
            g.setColor(Color.lightGray);
            g.setFont(new Font("Arial",Font.PLAIN,50));
            g.drawString("HOW TO PLAY",Window.getWidth2()/2-150, (int) (Window.getHeight2()*heightNum));
           
//            
            Color newCol = new Color(0, 128, 128);
            g.setColor(newCol);
            g.setFont(new Font("Arial",Font.PLAIN,15));
            g.drawString("Checkers is a board game played between two people with 12 pieces each",Window.getWidth2()/2-225, 200);
            g.drawString("that are different colors. The pieces are placed on every other dark square",Window.getWidth2()/2-225, 215);
            g.drawString("and then staggered by rows.",Window.getWidth2()/2-225, 230);
           
             
            g.setColor(newColo);
            g.drawString("TAKING A TURN",Window.getWidth2()/2-225, 250);
            g.drawString("Each player takes their turn by moving a piece. Pieces are always moved",Window.getWidth2()/2-225, 265);
            g.drawString("diagonally and can be moved in the following ways: Diagonally in the forward",Window.getWidth2()/2-225, 280);
            g.drawString("direction (towards the opponent) to the next dark square. If there is one of the",Window.getWidth2()/2-225, 295);
            g.drawString("opponent's pieces next to a piece and an empty space on the other side, you",Window.getWidth2()/2-225, 310);
            g.drawString("jump your opponent and remove their piece. You can do multiple jumps if they",Window.getWidth2()/2-225, 325);
            g.drawString("are lined up in the forward direction.",Window.getWidth2()/2-225, 340);
            g.drawString("***note: if you have a jump, you have no choice but to take it.***",Window.getWidth2()/2-225, 355);
           
            g.setColor(newCol);
            g.drawString("KING PIECES",Window.getWidth2()/2-225, 375);
            g.drawString("The last row is called the king row. If you get a piece across the board to the",Window.getWidth2()/2-225, 390);
            g.drawString("opponent's king row, that piece becomes a king. King pieces can move in both",Window.getWidth2()/2-225, 405);
            g.drawString("directions, forward and backward. Once a piece is kinged, the player must",Window.getWidth2()/2-225, 420);
            g.drawString("wait until the next turn to jump out of the king row.",Window.getWidth2()/2-225, 435);
           
            g.setColor(newColo);
            g.drawString("WINNING THE GAME",Window.getWidth2()/2-225, 455);
            g.drawString("You win the game when the opponent has no more pieces or can't move",Window.getWidth2()/2-225, 470);
            g.drawString("(even if he/she still has pieces). If neither player can move then it's a tie.",Window.getWidth2()/2-225, 485);
           
            g.setColor(newCol);
            g.drawString("BOMBS",Window.getWidth2()/2-225, 505);
            g.drawString("After each player makes 5 turns a bomb will appear randomly on the board.",Window.getWidth2()/2-225, 520);
            g.drawString("If a player jumps onto a bomb their piece is taken off the board and captured by ",Window.getWidth2()/2-225, 535);
            g.drawString("the opposing player. A bomb can only explode one time per bomb.",Window.getWidth2()/2-225, 550);
           
           
           
        }
       
       
        //create a bounding box type thing and if the mouse is clicked in it set a boolean to true and dispaly the rules
             
        Board.Draw(g);
       
        gOld.drawImage(image, 0, 0, null);
    }

////////////////////////////////////////////////////////////////////////////
// needed for     implement runnable
    public void run() {
        while (true) {
            animate();
            repaint();
            double seconds = .1;    //time that 1 frame takes.
            int miliseconds = (int) (1000.0 * seconds);
            try {
                Thread.sleep(miliseconds);
            } catch (InterruptedException e) {
            }
        }
    }
   
/////////////////////////////////////////////////////////////////////////
    public void reset() {
        Player.Reset();
        Board.Reset();
        mouseClicks = 0;
    }
/////////////////////////////////////////////////////////////////////////
    public void animate() {

        if (animateFirstTime) {
            animateFirstTime = false;
            if (Window.xsize != getSize().width || Window.ysize != getSize().height) {
                Window.xsize = getSize().width;
                Window.ysize = getSize().height;
            }

            checkersBoardImage = Toolkit.getDefaultToolkit().getImage("./checkersBoard.png");
           
                reset();

        }

       
    }

////////////////////////////////////////////////////////////////////////////
    public void start() {
        if (relaxer == null) {
            relaxer = new Thread(this);
            relaxer.start();
        }
    }
////////////////////////////////////////////////////////////////////////////
    public void stop() {
        if (relaxer.isAlive()) {
            relaxer.stop();
        }
        relaxer = null;
    }

}